**Quest**

**The Pursuit of Knowledge**

  Quest is a MERN based webapp where you can find the best answers in all topics from experts,friends and communities.

**Functionalities**
  
  User can post the question
  
  User can find the answers based on their search
  
  User can post the answer for a particular question
  
  User can follow/unfollow the question
  
  User can like/dislike the answers

**How to start running**

  Run these commands

  To install the required dependencies

  $ npm install
  To build the app


  $ npm start
  To start your webapp (ensure that your mongo server is running before you start your boilerplate)
